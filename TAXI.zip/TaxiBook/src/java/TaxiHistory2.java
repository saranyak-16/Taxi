/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import database.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.LinkedList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Saranya
 */
@WebServlet(urlPatterns = {"/TaxiHistory2"})
public class TaxiHistory2 extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        int taxi_no=Integer.parseInt(request.getParameter("id"));
  System.out.println("This is Taxi History-------------------------------------------->");

        try (PrintWriter out = response.getWriter()) {
            out.println("<h1>Taxi No: " + taxi_no+ "</h1>");
            
            out.println("<table cellspacing='0' width='100%' border='4'>");

            out.println("<tr  bgcolor='pink'>");
            
            out.println("<th>SNO</th>");
        out.println("<th>Start</th>");
        out.println("<th>Destination</th>");
        out.println("<th>Start time</th>");
        out.println("<th>Reach time</th>");
        out.println("<th>Price</th>");
        
            LinkedList<TaxiHistory> history=new History().record(taxi_no);
            Iterator<TaxiHistory>it=history.iterator();
        
        while(it.hasNext()){
            TaxiHistory in=it.next();
            out.println("<tr>");
            out.println("<td align='center'>"+in.getSno()+"</td>");
            out.println("<td>"+in.getStart()+"</td>");
            out.println("<td align='center'>"+in.getDestination()+"</td>");
            out.println("<td>"+in.getStartTime()+"</td>");
            out.println("<td>"+in.getReachTime()+"</td>");
            out.println("<td>"+in.getPrice()+"</td>");
            out.println("</tr>");
            //System.out.println("       "++"      "++"       "+);
        }
           // out.println("<h1>Servlet TaxiHistory1 at " + request.getContextPath() + "</h1>");
           
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
