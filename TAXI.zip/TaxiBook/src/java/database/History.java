/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Time;
import java.util.HashMap;
import java.util.LinkedList;

public class History {
    

    public LinkedList<TaxiHistory> record(int taxi_id){
        LinkedList<TaxiHistory> list=new LinkedList<>();
        
        try
        {
           Connection con=DBConnect.getCon();
           PreparedStatement pst=con.prepareStatement("select * from taxi_history");

           ResultSet rst=pst.executeQuery();

           while(rst.next())
           {
               TaxiHistory th=new TaxiHistory();
               th.setSno(rst.getInt("s_no"));
               th.setStart(rst.getString("starting"));
               th.setDestination(rst.getString("destination"));
               th.setPrice(rst.getInt("Price"));
               String st=rst.getString("starttime");
               String dt=rst.getString("reachTime");
               String st1[]=st.split("[:]");
               String dt2[]=dt.split("[:]");
               Time s=new Time(Integer.parseInt(st1[0]), Integer.parseInt(st1[1]), 0);
               Time d=new Time(Integer.parseInt(dt2[0]), Integer.parseInt(dt2[1]), 0);
               th.setStartTime(s);
               th.setReachTime(d);
               
               th.setStart(rst.getString("starting"));
               
               int taxi=rst.getInt("taxi_id");
               if(taxi_id==taxi){
               
               list.add(th);
               }
               
               
           }
        
        
        con.commit();
        
    con.close();
            System.out.println("success");
         }
         catch(Exception e)
         {
             System.out.println(e.toString());
         }
         return list;
    }
    
    public void updateHistory(int taxi_no,TaxiHistory th){
     System.out.println("This is Update-------------------------------------------->");

        try{
        Connection con=DBConnect.getCon();
           PreparedStatement pst=con.prepareStatement("insert into taxi_history values(?,?,?,?,?,?,?,?)");

           pst.setInt(1,th.getSno());
           pst.setInt(2,1);
           pst.setString(3,th.getStart());
           pst.setString(4,th.getDestination());
           String s1=th.getStartTime().getHours()+":"+th.getStartTime().getMinutes();
           String s2=th.getReachTime().getHours()+":"+th.getReachTime().getMinutes();
           pst.setString(5,s1);
           pst.setString(6,s2);
           pst.setInt(7,th.getPrice());
           pst.setDouble(8,taxi_no);
           pst.executeUpdate();
           con.commit();
           con.close();
        }catch(Exception ee){
            System.out.println(ee);
        }
    }
    public void restWindow(int id,int taxi_id){
        try{
            Connection con=DBConnect.getCon();
       
           String str="";
           if(id==1){
               str="update restWindow set status='rest' where taxi_no="+taxi_id;
           }else{
               str="update restWindow set status='not rest' where taxi_no="+taxi_id;
           }
            PreparedStatement pst1=con.prepareStatement(str);

           ResultSet rst1=pst1.executeQuery();
           con.commit();
           con.close();
        }catch(Exception ee){
            
        }
    }
    
    public HashMap<Integer,String> totalTaxis(){
        HashMap<Integer,String> mp=new HashMap<>();
        try{
            Connection con=DBConnect.getCon();
        PreparedStatement pst1=con.prepareStatement("select * from restWindow");

           ResultSet rst1=pst1.executeQuery();
           
           while(rst1.next())
           {
               String s=rst1.getString("status");
               int taxi_no=rst1.getInt("taxi_no");
               mp.put(taxi_no, s);
                 
           }
           
           con.close();
        }catch(Exception e1){
            
        }
        return mp;
    }
    public void TaxiLess(int id,int total){
        try{
            Connection con=DBConnect.getCon();
        PreparedStatement pst1=con.prepareStatement(" delete from restwindow where taxi_no>"+id);

           ResultSet rst1=pst1.executeQuery();
           con.commit();
           
           PreparedStatement pst2=con.prepareStatement(" delete from taxi_history where taxi_id>"+id);

           ResultSet rst2=pst2.executeQuery();
           con.commit();
           
        con.close();
        }catch(Exception e1){
            System.out.println(e1);
        }
    }
    public void TaxiGreat(int id,int total){
        
        try{
            Connection con=DBConnect.getCon();
        
        for(int i=total+1;i<=id;i++){
            
            PreparedStatement pst1=con.prepareStatement(" insert into restwindow values("+i+",'not rest')");
          ResultSet rst1=pst1.executeQuery();
            System.out.println("---------------------------->");
          con.commit();
        }
        
           
           
        con.close();
        }catch(Exception e1){
            System.out.println(e1);
        }
        
    }
    
}
