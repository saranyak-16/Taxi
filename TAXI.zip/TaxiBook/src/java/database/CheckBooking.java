/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

public class CheckBooking {
    int n=5;
    public  HashMap<Integer,LinkedList<TaxiHistory>> History=new HashMap<Integer,LinkedList<TaxiHistory>>();
    public  String cities[]={"DLF","Velachery","Tambaram","TNagar","Nungambakkam"};
    public  int min=Integer.MAX_VALUE;
    public  ArrayList<Integer> al=new ArrayList<>();
    public  ArrayList<Boolean> cabs=new ArrayList<>();

    public CheckBooking() {
        for(int i=0;i<n;i++){
          LinkedList<TaxiHistory>th=new LinkedList<>();
          History.put(i+1, th);
          cabs.add(true);
      }
    }
    
    
    

    public int checkLocation(String s, String d) {
        int i1 = 0, i2 = 0, i = 0;
        for (String ss : cities) {
            if (ss.equals(s)) {
                i1 = i;
            }
            if (ss.equals(d)) {
                i2 = i;
            }
            i++;
        }
        return (i1 > i2) ? i1 - i2 : i2 - i1;
    }

    public int checkNearest(String start, String dest, Time pickTime, int s,int times) {
        min = Integer.MAX_VALUE;
        // Map.Entry<Integer,LinkedList<TaxiHistory>> ep=History.entrySet();
        for (Map.Entry<Integer, LinkedList<TaxiHistory>> mp : History.entrySet()) {
            LinkedList<TaxiHistory> list = mp.getValue();

            if (list.size() == 0) {
                int t = checkLocation(start, "DLF");
                if (s < t && t < min) {
                    al.clear();
                    min = t;
                    System.out.println("-------->" + t);
                    al.add(mp.getKey());
                } else if (min == t) {
                    al.add(mp.getKey());
                }
            } else {
                TaxiHistory one = list.get(list.size() - 1);
                int t = checkLocation(start, one.getDestination());
                if (s < t && t < min) {
                    al.clear();
                    min = t;
                    al.add(mp.getKey());
                } else if (min == t) {
                    al.add(mp.getKey());
                }
            }
        }

        int taxi = checkBook(pickTime);
        if (taxi == 0) {
            System.out.println(taxi + "=======");
            al.clear();
            times++;
            if(times>=2){
                return 0;
            }
           return checkNearest(start, dest, pickTime, min,times);

        } else {
            System.out.println(taxi + "---------->");
            LinkedList<TaxiHistory> link = History.get(taxi);
            if (link.size() == 0) {

                TaxiHistory th = new TaxiHistory();
                if (start.equals("DLF")) {
                    th.setSno(1);
                    th.setStart(start);
                    th.setDestination(dest);
                    th.setStartTime(pickTime);
                    int value = checkLocation(start, dest);

                    th.setPrice(value * 150);
                    System.out.println(value + "--->value\n");

                    int mins = pickTime.getMinutes() + (value * 15);

                    int hour = pickTime.getHours() + (mins / 60);
                    int minutes = (mins % 60);
                    th.setReachTime(new Time(hour, minutes, 0));
                    link.add(th);
                    new History().updateHistory(taxi, th);
                    History.put(taxi, link);
                } else {

                    int value = checkLocation("DLF", start);

                    int price = -(value * 15 * 5);

                    TaxiHistory th1 = new TaxiHistory();
                    th1.setSno(1);
                    th1.setStart(start);
                    th1.setDestination(dest);
                    th1.setStartTime(pickTime);

                    int value1 = checkLocation(start, dest);

                    th1.setPrice(value1 * 150 + (price));

                    int mins1 = pickTime.getMinutes() + (value1 * 15);
                    int hour1 = pickTime.getHours() + (mins1 / 60);
                    int minutes1 = (mins1 % 60);

                    th1.setReachTime(new Time(hour1, minutes1, 0));
                    link.add(th1);
                    new History().updateHistory(taxi, th1);
                    History.put(taxi, link);
                }
            } else {
                TaxiHistory the = link.get(link.size() - 1);
                if (checkLocation(start, the.getDestination()) == 0) {
                    TaxiHistory th = new TaxiHistory();
                    th.setSno(the.getSno() + 1);
                    th.setStart(start);
                    th.setDestination(dest);
                    th.setStartTime(pickTime);

                    int value = checkLocation(start, dest);
                    th.setPrice((150 * value));
                    System.out.println(value + "--->value");
                    int mins = pickTime.getMinutes() + (value * 15);
                    int hour = pickTime.getHours() + (mins / 60);
                    int minutes = (mins % 60);
                    th.setReachTime(new Time(hour, minutes, 0));
                    link.add(th);
                    new History().updateHistory(taxi, th);
                    History.put(taxi, link);
                } else {

                    int value = checkLocation(the.getDestination(), start);
                    int price = -(value * 15 * 5);

                    TaxiHistory th1 = new TaxiHistory();
                    th1.setSno(the.getSno() + 1);
                    th1.setStart(start);
                    th1.setDestination(dest);
                    th1.setStartTime(pickTime);

                    int value1 = checkLocation(the.getDestination(), start);
                    th1.setPrice(value1 * 150 + (price));

                    int mins1 = pickTime.getMinutes() + (value1 * 15);
                    int hour1 = pickTime.getHours() + (mins1 / 60);
                    int minutes1 = pickTime.getMinutes() + (mins1 % 60);

                    th1.setReachTime(new Time(hour1, minutes1, 0));
                    link.add(th1);
                    new History().updateHistory(taxi, th1);
                    History.put(taxi, link);

                }

            }

        }
        return taxi;
    }

    public int checkBook(Time stime) {
        System.out.println(al);
        int min = Integer.MAX_VALUE;
        int taxi = 0;
        for (int i : al) {
            int sum = 0;
            LinkedList<TaxiHistory> ans = History.get(i);
            Iterator<TaxiHistory> it = ans.iterator();
            Time current = new Time(0, 0, 0);
            while (it.hasNext()) {
                TaxiHistory in = it.next();
                sum = sum + in.getPrice();
                current = in.getReachTime();
            }

            if (sum < min && cabs.get(i - 1)) {
                if (stime.getHours() >= current.getHours()) {
                    if (stime.getHours() == current.getHours()) {
                        if (stime.getMinutes() >= current.getMinutes()) {
                            taxi = i;
                            min = sum;
                        }
                    } else {
                        taxi = i;
                        min = sum;
                    }
                }

            }
        }

        return taxi;
    }

    public int checkBooking(String start, String destination, String pickTime) {
        al.clear();
        String ar[] = pickTime.split("[:]");
        Time pickUp = new Time(Integer.parseInt(ar[0]), Integer.parseInt(ar[1]), 0);
        
        try
        {
           Connection con=DBConnect.getCon();
           PreparedStatement pst=con.prepareStatement("select * from taxi_history");

           ResultSet rst=pst.executeQuery();

           while(rst.next())
           {
               TaxiHistory th=new TaxiHistory();
               th.setSno(rst.getInt("s_no"));
               th.setStart(rst.getString("starting"));
               th.setDestination(rst.getString("destination"));
               th.setPrice(rst.getInt("Price"));
               String st=rst.getString("starttime");
               String dt=rst.getString("reachTime");
               String st1[]=st.split("[:]");
               String dt2[]=dt.split("[:]");
               Time s=new Time(Integer.parseInt(st1[0]), Integer.parseInt(st1[1]), 0);
               Time d=new Time(Integer.parseInt(dt2[0]), Integer.parseInt(dt2[1]), 0);
               th.setStartTime(s);
               th.setReachTime(d);
               
               th.setStart(rst.getString("starting"));
               
               int taxi=rst.getInt("taxi_id");
               LinkedList<TaxiHistory> ll=History.get(taxi);
               ll.add(th);
               History.put(taxi, ll);
               
           }
           System.out.println(History);
           PreparedStatement pst1=con.prepareStatement("select * from restWindow");

           ResultSet rst1=pst1.executeQuery();
           
           while(rst1.next())
           {
               String s=rst1.getString("status");
               int taxi_no=rst1.getInt("taxi_no");
               if(s.equals("rest"))
               cabs.set(taxi_no-1, Boolean.FALSE);
               else
               cabs.set(taxi_no-1, Boolean.TRUE);   
           }
           
           con.close();
            System.out.println("success");
         }
         catch(Exception e)
         {
             System.out.println(e.toString());
         }
        
        
        
        
        
        
        
        return checkNearest(start, destination, pickUp, -1,0);
    }
    
}
