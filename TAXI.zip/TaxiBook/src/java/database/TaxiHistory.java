/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;
import java.sql.Time;


public class TaxiHistory {
    int sno;
    String start;
    String destination;
    Time startTime;
    Time reachTime;
    int Price;

    public String getDestination() {
        return destination;
    }

    public int getPrice() {
        return Price;
    }

    public Time getReachTime() {
        return reachTime;
    }

    public int getSno() {
        return sno;
    }

    public String getStart() {
        return start;
    }

    public Time getStartTime() {
        return startTime;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public void setPrice(int Price) {
        this.Price = Price;
    }

    public void setReachTime(Time reachTime) {
        this.reachTime = reachTime;
    }

    public void setSno(int sno) {
        this.sno = sno;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public void setStartTime(Time startTime) {
        this.startTime = startTime;
    }
    
    
}
