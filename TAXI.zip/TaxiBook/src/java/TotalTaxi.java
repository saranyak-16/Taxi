/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import database.History;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns = {"/TotalTaxi"})
public class TotalTaxi extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        HashMap<Integer,String> mp=new History().totalTaxis();
        
        int total=mp.size();
        try (PrintWriter out = response.getWriter()) {
            out.println("<h1>Total no. of Taxis : " + total+ "</h1>");
            out.println("<table cellspacing='0' width='100%' border='4'>");

            out.println("<tr  bgcolor='pink'>");
            
            out.println("<th>Taxi :No</th>");
            out.println("<th>Status</th>");
            
            for (Map.Entry<Integer, String> set :mp.entrySet()) {
 
            // Printing all elements of a Map
            System.out.println(set.getKey() + " = "+ set.getValue());
            out.println("<tr>");
            out.println("<td align='center'>"+set.getKey()+"</td>");
            out.println("<td>"+set.getValue()+"</td>");
            out.println("</tr>");
        }
        
        
        
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
